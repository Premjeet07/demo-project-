package com.infinite.jsf.admin.model;

public enum PaymentStatus {
	pending,completed,failed;
}
